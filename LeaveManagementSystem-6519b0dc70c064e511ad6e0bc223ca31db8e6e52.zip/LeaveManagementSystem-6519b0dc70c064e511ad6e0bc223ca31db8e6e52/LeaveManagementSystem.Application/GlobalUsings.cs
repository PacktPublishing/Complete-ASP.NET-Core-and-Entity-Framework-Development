﻿global using LeaveManagementSystem.Common.Static;
global using LeaveManagementSystem.Data;
global using Microsoft.AspNetCore.Identity;
global using Microsoft.AspNetCore.Identity.UI.Services;
global using System.ComponentModel.DataAnnotations;
global using LeaveManagementSystem.Application.Models.LeaveAllocations;
global using LeaveManagementSystem.Application.Models.LeaveRequests;
global using LeaveManagementSystem.Application.Models.LeaveTypes;
global using LeaveManagementSystem.Application.Models.Periods;

