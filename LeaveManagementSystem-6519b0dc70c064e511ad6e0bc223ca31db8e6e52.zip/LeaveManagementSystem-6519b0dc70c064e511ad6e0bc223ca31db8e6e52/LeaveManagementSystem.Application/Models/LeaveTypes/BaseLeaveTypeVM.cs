﻿namespace LeaveManagementSystem.Application.Models.LeaveTypes
{
    public abstract class BaseLeaveTypeVM
    {
        public int Id { get; set; }
    }
}
