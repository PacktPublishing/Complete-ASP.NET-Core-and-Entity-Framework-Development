﻿namespace LeaveManagementSystem.Application.Models.LeaveAllocations
{
    public class LeaveAllocationEditVM : LeaveAllocationVM
    {
        public EmployeeListVM? Employee { get; set; }
    }
}