﻿namespace LeaveManagementSystem.Application.Models
{
    public class TestViewModel
    {
        public string Name { get; set; }
        public DateTime? DateOfBirth { get; set; }
    }
}
